"use client";
import React from "react";
import * as MarkdownRenderer from "@/libraries/markdown-renderer";

function MainComponent() {
  const [input, setInput] = React.useState("");
  const [conversation, setConversation] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const messagesEndRef = React.useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  React.useEffect(scrollToBottom, [conversation]);

  const handleSend = async () => {
    if (!input || loading) return;
    setLoading(true);
    const userMessage = { role: "user", content: input };
    const newConversation = [...conversation, userMessage];
    setConversation(newConversation);
    setInput("");

    try {
      const response = await fetch("/integrations/groq/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newConversation }),
      });
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      const data = await response.json();
      const assistantMessage = {
        role: "assistant",
        content: data.choices[0]?.message?.content || "No response available",
      };
      setConversation([...newConversation, assistantMessage]);
    } catch (error) {
      console.error("Error calling GROQ:", error);
      setConversation([
        ...newConversation,
        {
          role: "assistant",
          content: "Sorry, an error occurred. Please try again.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const renderMessageContent = (content) => {
    const codeBlockPattern = /[\s\S]*?/g;
    let match;
    const elements = [];
    let lastIndex = 0;

    while ((match = codeBlockPattern.exec(content)) !== null) {
      const textBefore = content.slice(lastIndex, match.index);
      if (textBefore) {
        elements.push(
          <MarkdownRenderer.Display key={lastIndex}>
            {textBefore}
          </MarkdownRenderer.Display>
        );
      }
      const codeBlock = match[0].slice(3, -3).trim();
      elements.push(
        <button
          key={match.index}
          className="bg-[#3b5998] text-white px-2 py-1 rounded-md mt-1"
          onClick={() => navigator.clipboard.writeText(codeBlock)}
        >
          Copy Code
        </button>
      );
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < content.length) {
      elements.push(
        <MarkdownRenderer.Display key={lastIndex}>
          {content.slice(lastIndex)}
        </MarkdownRenderer.Display>
      );
    }

    return elements;
  };

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-[#1a1a1a] shadow-md rounded-lg overflow-hidden text-[#e0e0e0]">
      <div className="flex-grow p-4 overflow-y-auto pb-20">
        {conversation.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-red-500 to-green-500">
              INFlash AI
            </h1>
          </div>
        )}
        {conversation.map((msg, index) => (
          <div
            key={index}
            className={`mb-2 p-2 rounded-lg ${
              msg.role === "user"
                ? "bg-[#2c3e50] text-[#e0e0e0] self-end"
                : "bg-[#34495e] text-[#e0e0e0] self-start"
            } flex items-start`}
          >
            {msg.role === "user" ? (
              <i
                className="fas fa-user-circle text-[#7f8c8d] text-xl mx-2 mt-0.5"
                aria-label="User"
              ></i>
            ) : (
              <span className="bg-[#7f8c8d] text-sm px-2 py-1 rounded-md mx-2 mt-0.5">
                AI
              </span>
            )}
            <div className="flex-grow">{renderMessageContent(msg.content)}</div>
          </div>
        ))}
        {loading && (
          <div className="self-start bg-[#34495e] text-[#e0e0e0] p-2 rounded-lg">
            Typing...
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="border-t border-[#2c3e50] p-4 flex items-center fixed bottom-0 left-0 right-0 bg-[#1a1a1a]">
        <input
          className="flex-grow p-2 bg-[#2c3e50] text-[#e0e0e0] border border-[#34495e] rounded-lg mr-2 placeholder-[#7f8c8d]"
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          name="messageInput"
        />
        <button
          className="bg-[#34495e] text-[#e0e0e0] px-4 py-2 rounded-md border-none cursor-pointer flex items-center hover:bg-[#2c3e50] disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={handleSend}
          disabled={loading || !input.trim()}
          aria-label="Send message"
        >
          <span className="mr-1">Send</span>
          <i className="fas fa-paper-plane"></i>
        </button>
      </div>
    </div>
  );
}

export default MainComponent;